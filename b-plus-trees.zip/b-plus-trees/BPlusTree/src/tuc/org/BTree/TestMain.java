package tuc.org.BTree;

import tuc.org.util.Generate;
import tuc.org.util.MultiCounter;
import tuc.org.util.Tester;

import java.io.IOException;
import java.util.Random;

public class TestMain {
    private static final int NO_OF_INSERTIONS= 20;
    private static final int NO_OF_SEARCHES= 20;
    private static final int NO_OF_DELETIONS = 20;
    private static final int K1 = 10;
    private static final int K2 = 1000;

    public static void main(String[] args) throws IOException {


        Tester test = new Tester();

        MultiCounter.resetCounter(1);
        test.CallToInsertKeys();
        System.out.println("Average disk acceses for 20 insertion:"+MultiCounter.getCount(1)/NO_OF_INSERTIONS);

        MultiCounter.resetCounter(1);
        test.CallToSearch();
        System.out.println("Average disk acceses for 20 searches:"+MultiCounter.getCount(1)/NO_OF_SEARCHES);

        MultiCounter.resetCounter(1);
        test.CallToDelete();
        System.out.println("Average disk acceses for 20 deletions:"+MultiCounter.getCount(1)/NO_OF_DELETIONS);

        //test.CallToSearch();

//        MultiCounter.resetCounter(1);
//        test.CallToSearchKeysInRange(K1);
//        System.out.println("Average disk acceses when searching:"+MultiCounter.getCount(1)/NO_OF_SEARCHES);
//
//        MultiCounter.resetCounter(1);
//        test.CallToSearchKeysInRange(K2);
//        System.out.println("Average disk acceses when searching:"+MultiCounter.getCount(1)/NO_OF_SEARCHES);

    }
}