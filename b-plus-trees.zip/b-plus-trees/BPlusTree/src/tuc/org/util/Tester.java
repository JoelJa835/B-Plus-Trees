package tuc.org.util;
import tuc.org.BTree.BTree;
import tuc.org.BTree.Data;

import java.io.IOException;
import java.util.Arrays;
import java.util.Random;
public class Tester {

    /**
     * A class that is used to help clean up our main function
     */

        private static final int START_INT = 1;
        private static final int END_INT = 1000001;
        private static final int NO_OF_ELEMENTS = 100000;
        private static final int NO_OF_INSERTIONS= 20;
        private static final int NO_OF_SEARCHES= 20;
        private static final int NO_OF_DELETIONS = 20;

        Generate gen = new Generate();
        BTree tree = new BTree();
        int[] RandKeys = gen.RandomInts(START_INT,END_INT,NO_OF_ELEMENTS+NO_OF_SEARCHES);

    public Tester() throws IOException {
    }
        public static int[] getRandomKeys(int n, int[] keys) {

            Random rand = new Random();
            int[] array = new int[n];

            for(int i=0; i<n; i++) {
                array[i] = keys[rand.nextInt(keys.length)];
            }
            return array;
        }

        public void CallToInsertKeys() throws IOException {
            System.out.println("Inserting keys, this may take a bit!");
            for(int i=0;i<NO_OF_ELEMENTS+NO_OF_SEARCHES;i++){
                if(i == NO_OF_ELEMENTS){
                    MultiCounter.resetCounter(1);
                }
                int int1 = getRandomKeys(NO_OF_ELEMENTS+NO_OF_SEARCHES,RandKeys)[i];
                int int2= getRandomKeys(NO_OF_ELEMENTS+NO_OF_SEARCHES,RandKeys)[i];
                int int3= getRandomKeys(NO_OF_ELEMENTS+NO_OF_SEARCHES,RandKeys)[i];
                int int4= getRandomKeys(NO_OF_ELEMENTS+NO_OF_SEARCHES,RandKeys)[i];
                int int5= getRandomKeys(NO_OF_ELEMENTS+NO_OF_SEARCHES,RandKeys)[i];
                int int6= getRandomKeys(NO_OF_ELEMENTS+NO_OF_SEARCHES,RandKeys)[i];
                int int7= getRandomKeys(NO_OF_ELEMENTS+NO_OF_SEARCHES,RandKeys)[i];
                int int8= getRandomKeys(NO_OF_ELEMENTS+NO_OF_SEARCHES,RandKeys)[i];
                tree.insert(Integer.valueOf(RandKeys[i]),new Data(int1,int2,int3,int4,int5,int6,int7,int8));
            }
        }

        public void CallToSearch() throws IOException {
            for(int i=0;i<NO_OF_SEARCHES;i++){
                System.out.println("Found key at:"+tree.search(getRandomKeys(NO_OF_ELEMENTS,RandKeys)[i]));
            }
        }
        public void CallToDelete() throws IOException {
            for(int i=0;i<NO_OF_DELETIONS;i++){
                tree.delete(getRandomKeys(NO_OF_ELEMENTS,RandKeys)[i]);
            }
        }

    public void CallToSearchKeysInRange(int K) {
        for (int i = 0; i < NO_OF_SEARCHES; i++) {
            int num = getRandomKeys(NO_OF_SEARCHES,RandKeys)[i];

        }
    }

    }

